def console(msg: str):
    print(msg, flush=True)
